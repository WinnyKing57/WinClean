# -*- coding: utf-8 -*-
"""
Module UI modernisé pour le Debian Storage Analyzer
"""